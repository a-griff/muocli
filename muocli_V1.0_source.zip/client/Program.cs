using System;
using System.IO;
using System.Net.Sockets;

class Program
{
    static int Main(string[] args)
    {
        string host = "127.0.0.1";
        int port = 2594;
        string token = Environment.GetEnvironmentVariable("MUOCLI_TOKEN") ?? "";
        string command = "";

        for (int i = 0; i < args.Length; i++)
        {
            switch (args[i])
            {
                case "--host":
                    host = args[++i];
                    break;

                case "--port":
                    port = int.Parse(args[++i]);
                    break;

                case "--token":
                    token = args[++i];
                    break;

                default:
                    command += (command == "" ? "" : " ") + args[i];
                    break;
            }
        }

        if (command == "" || token == "")
        {
            Console.WriteLine("Usage:");
            Console.WriteLine("  muocli --token TOKEN <command>");
            return 1;
        }

        try
        {
            using var client = new TcpClient();
            client.Connect(host, port);

            using var stream = client.GetStream();
            using var reader = new StreamReader(stream);
            using var writer = new StreamWriter(stream) { AutoFlush = true };

            writer.WriteLine($"{token} {command}");

            while (true)
            {
                string? line = reader.ReadLine();

                if (line == null)
                    break;

                Console.WriteLine(line);

                if (line == "." ||
                    line.StartsWith("OK pong") ||
                    line.StartsWith("ERR "))
                {
                    break;
                }
            }

            return 0;
        }
        catch (Exception ex)
        {
            Console.WriteLine("ERROR: " + ex.Message);
            return 1;
        }
    }
}

