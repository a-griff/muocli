using System;
using System.IO;
using System.Linq;
using Server;
using Server.Accounting;

internal static class AccountCommands
{
    public static void Dispatch(StreamWriter writer, string[] args)
    {
        switch (args[1])
        {
            case "list":
                List(writer);
                return;

            case "show":
                Show(writer, args);
                return;

            case "create":
                Create(writer, args);
                return;

            case "delete":
                Delete(writer, args);
                return;

            case "passwd":
                Passwd(writer, args);
                return;

            case "access":
                Access(writer, args);
                return;
        }

        writer.WriteLine("ERR unknown-command");
    }

    private static void List(StreamWriter writer)
    {
        string result = ServerThread.Run(() =>
        {
            var accounts = Accounts.GetAccounts()
                .OrderBy(a => a.Username)
                .ToList();

            StringWriter sw = new StringWriter();

            sw.WriteLine("OK accounts " + accounts.Count);

            foreach (var a in accounts)
                sw.WriteLine($"{a.Username}\t{a.AccessLevel}\tchars={a.Count}/{a.Limit}");

            sw.WriteLine(".");

            return sw.ToString().TrimEnd();
        });

        ResponseWriter.WriteMultiline(writer, result);
    }

    private static void Show(StreamWriter writer, string[] args)
    {
        if (args.Length != 3)
        {
            writer.WriteLine("ERR usage: accounts show <username>");
            return;
        }

        string username = args[2];

        string result = ServerThread.Run(() =>
        {
            IAccount? a = Accounts.GetAccount(username);

            if (a == null)
                return "ERR account-not-found";

            StringWriter sw = new StringWriter();

            sw.WriteLine("OK account");
            sw.WriteLine("username=" + a.Username);
            sw.WriteLine("email=" + a.Email);
            sw.WriteLine("access=" + a.AccessLevel);
            sw.WriteLine("chars=" + a.Count + "/" + a.Limit);
            sw.WriteLine("gold=" + a.TotalGold);
            sw.WriteLine("plat=" + a.TotalPlat);
            sw.WriteLine(".");

            return sw.ToString().TrimEnd();
        });

        ResponseWriter.WriteMultiline(writer, result);
    }

    private static void Create(StreamWriter writer, string[] args)
    {
        if (args.Length != 4)
        {
            writer.WriteLine("ERR usage: accounts create <username> <password>");
            return;
        }

        string username = args[2];
        string password = args[3];

        string result = ServerThread.Run(() =>
        {
            if (Accounts.GetAccount(username) != null)
                return "ERR account-exists";

            new Account(username, password);

            return "OK account-created " + username;
        });

        writer.WriteLine(result);
    }

    private static void Delete(StreamWriter writer, string[] args)
    {
        if (args.Length != 3)
        {
            writer.WriteLine("ERR usage: accounts delete <username>");
            return;
        }

        string username = args[2];

        string result = ServerThread.Run(() =>
        {
            IAccount? a = Accounts.GetAccount(username);

            if (a == null)
                return "ERR account-not-found";

            a.Delete();

            return "OK account-deleted " + username;
        });

        writer.WriteLine(result);
    }

    private static void Passwd(StreamWriter writer, string[] args)
    {
        if (args.Length != 4)
        {
            writer.WriteLine("ERR usage: accounts passwd <username> <password>");
            return;
        }

        string username = args[2];
        string password = args[3];

        string result = ServerThread.Run(() =>
        {
            IAccount? a = Accounts.GetAccount(username);

            if (a == null)
                return "ERR account-not-found";

            a.SetPassword(password);

            return "OK password-changed " + username;
        });

        writer.WriteLine(result);
    }

    private static void Access(StreamWriter writer, string[] args)
    {
        if (args.Length != 4)
        {
            writer.WriteLine("ERR usage: accounts access <username> <level>");
            return;
        }

        string username = args[2];
        string access = args[3];

        string result = ServerThread.Run(() =>
        {
            IAccount? a = Accounts.GetAccount(username);

            if (a == null)
                return "ERR account-not-found";

            if (!Enum.TryParse(access, true, out AccessLevel level))
                return "ERR invalid-access-level";

            a.AccessLevel = level;

            return "OK access-changed " + username + " " + level;
        });

        writer.WriteLine(result);
    }
}
