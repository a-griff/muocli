using System.IO;
using Server;
using Server.Network;

internal static class PlayerCommands
{
    public static void Dispatch(StreamWriter writer, string[] args)
    {
        switch (args[1])
        {
            case "online":
            case "list":
                Online(writer);
                return;
        }

        writer.WriteLine("ERR unknown-command");
    }

    private static void Online(StreamWriter writer)
    {
        string result = ServerThread.Run(() =>
        {
            StringWriter sw = new StringWriter();
            int count = 0;

            foreach (NetState ns in NetState.Instances)
            {
                if (ns.Mobile != null)
                    count++;
            }

            sw.WriteLine("OK players " + count);

            foreach (NetState ns in NetState.Instances)
            {
                Mobile? mobile = ns.Mobile;

                if (mobile == null)
                    continue;

                string name = mobile.Name ?? "(no-name)";
                string account = mobile.Account?.Username ?? "(no-account)";

                sw.WriteLine($"{name}\t{account}\t{mobile.Map}\t{mobile.Location}");
            }

            sw.WriteLine(".");

            return sw.ToString().TrimEnd();
        });

        ResponseWriter.WriteMultiline(writer, result);
    }
}
