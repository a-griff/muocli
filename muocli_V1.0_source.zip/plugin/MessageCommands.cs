using System.IO;
using Server;

internal static class MessageCommands
{
    public static void Broadcast(StreamWriter writer, string cmd)
    {
        string message = CommandText.Remainder(cmd, 1);

        if (message == "")
        {
            writer.WriteLine("ERR usage: bcast <message>");
            return;
        }

        string result = ServerThread.Run(() =>
        {
            World.Broadcast(0x482, false, message);
            return "OK broadcast-sent";
        });

        writer.WriteLine(result);
    }

    public static void PlayerMessage(StreamWriter writer, string cmd)
    {
        string player = CommandText.Token(cmd, 1);
        string message = CommandText.Remainder(cmd, 2);

        if (player == "" || message == "")
        {
            writer.WriteLine("ERR usage: msg <player> <message>");
            return;
        }

        string result = ServerThread.Run(() =>
        {
            Mobile? mobile = PlayerLookup.FindOnlinePlayer(player);

            if (mobile == null)
                return "ERR player-not-found";

            mobile.SendMessage(0x482, message);
            return "OK message-sent " + mobile.Name;
        });

        writer.WriteLine(result);
    }
}
