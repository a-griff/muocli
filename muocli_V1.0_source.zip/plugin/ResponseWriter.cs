using System.IO;

internal static class ResponseWriter
{
    public static void WriteMultiline(StreamWriter writer, string text)
    {
        using (StringReader sr = new StringReader(text))
        {
            string? line;

            while ((line = sr.ReadLine()) != null)
                writer.WriteLine(line);
        }
    }
}
