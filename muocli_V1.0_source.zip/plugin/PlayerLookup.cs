using System;
using Server;
using Server.Network;

internal static class PlayerLookup
{
    public static Mobile? FindOnlinePlayer(string name)
    {
        foreach (NetState ns in NetState.Instances)
        {
            Mobile? mobile = ns.Mobile;

            if (mobile == null || mobile.Name == null)
                continue;

            if (mobile.Name.Equals(name, StringComparison.OrdinalIgnoreCase))
                return mobile;
        }

        return null;
    }
}
