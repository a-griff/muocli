using System;
using System.IO;

internal static class CommandDispatcher
{
    public static void Dispatch(StreamWriter writer, string cmd)
    {
        try
        {
            DispatchCore(writer, cmd);
        }
        catch (Exception ex)
        {
            Console.WriteLine("[muocli] Command failed: " + ex);
            writer.WriteLine("ERR exception: " + ex.GetType().Name + ": " + ex.Message);
        }
    }

    private static void DispatchCore(StreamWriter writer, string cmd)
    {
        string[] args = cmd.Split(' ', StringSplitOptions.RemoveEmptyEntries);

        if (args.Length == 0)
        {
            writer.WriteLine("ERR empty-command");
            return;
        }

        if (cmd.Equals("ping", StringComparison.OrdinalIgnoreCase))
        {
            writer.WriteLine("OK pong");
            return;
        }

        if (cmd.Equals("help", StringComparison.OrdinalIgnoreCase))
        {
            HelpCommand.Write(writer);
            return;
        }

        if (args[0].Equals("bcast", StringComparison.OrdinalIgnoreCase))
        {
            MessageCommands.Broadcast(writer, cmd);
            return;
        }

        if (args[0].Equals("msg", StringComparison.OrdinalIgnoreCase))
        {
            MessageCommands.PlayerMessage(writer, cmd);
            return;
        }

        if (args.Length >= 2 && args[0].Equals("accounts", StringComparison.OrdinalIgnoreCase))
        {
            AccountCommands.Dispatch(writer, args);
            return;
        }

        if (args.Length >= 2 && args[0].Equals("players", StringComparison.OrdinalIgnoreCase))
        {
            PlayerCommands.Dispatch(writer, args);
            return;
        }

        if (args.Length >= 2 && args[0].Equals("server", StringComparison.OrdinalIgnoreCase))
        {
            ServerCommands.Dispatch(writer, args);
            return;
        }

        writer.WriteLine("ERR unknown-command");
    }
}
