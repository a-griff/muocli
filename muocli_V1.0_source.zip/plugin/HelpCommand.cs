using System.IO;

internal static class HelpCommand
{
    public static void Write(StreamWriter writer)
    {
        writer.WriteLine("OK commands");
        writer.WriteLine("ping - Check whether muocli is responding.");
        writer.WriteLine("help - List available commands.");
        writer.WriteLine("accounts list - List all accounts.");
        writer.WriteLine("accounts show <username> - Show one account.");
        writer.WriteLine("accounts create <username> <password> - Create an account.");
        writer.WriteLine("accounts passwd <username> <password> - Change an account password.");
        writer.WriteLine("accounts access <username> <level> - Change an account access level.");
        writer.WriteLine("accounts delete <username> - Delete an account.");
        writer.WriteLine("players online - List online players.");
        writer.WriteLine("players list - Alias for players online.");
        writer.WriteLine("bcast <message> - Broadcast a message to all online players.");
        writer.WriteLine("msg <player> <message> - Send a message to one online player.");
        writer.WriteLine("server save - Save the world.");
        writer.WriteLine("server restart - Restart the ModernUO server.");
        writer.WriteLine("server shutdown - Shut down the ModernUO server.");
        writer.WriteLine(".");
    }
}
