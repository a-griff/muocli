using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;

public static class MuocliPlugin
{
    private static TcpListener? Listener;
    private static Thread? ListenerThread;
    private static bool Running;

    private static string Token = "";
    private static int Port = 2594;

    public static void Initialize()
    {
        string cfg = Path.Combine("Configuration", "muocli.cfg");

        if (!File.Exists(cfg))
        {
            Directory.CreateDirectory("Configuration");
            File.WriteAllText(cfg, "enabled=false\nport=2594\ntoken=CHANGE-ME\n");
            Console.WriteLine("[muocli] Created Configuration/muocli.cfg. Edit it and restart.");
            return;
        }

        foreach (string raw in File.ReadAllLines(cfg))
        {
            string line = raw.Trim();

            if (line == "" || line.StartsWith("#"))
                continue;

            string[] parts = line.Split('=', 2);
            if (parts.Length != 2)
                continue;

            string key = parts[0].Trim().ToLowerInvariant();
            string val = parts[1].Trim();

            if (key == "enabled" && val.ToLowerInvariant() != "true")
            {
                Console.WriteLine("[muocli] Disabled.");
                return;
            }

            if (key == "port")
            {
                if (int.TryParse(val, out int parsedPort) && parsedPort >= 1 && parsedPort <= 65535)
                {
                    Port = parsedPort;
                }
                else
                {
                    Console.WriteLine("[muocli] Invalid port in Configuration/muocli.cfg.");
                    return;
                }
            }

            if (key == "token")
                Token = val;
        }

        if (Token == "" || Token == "CHANGE-ME")
        {
            Console.WriteLine("[muocli] Refusing to start: token is not set.");
            return;
        }

        Running = true;
        ListenerThread = new Thread(ListenLoop);
        ListenerThread.IsBackground = true;
        ListenerThread.Start();

        Console.WriteLine($"[muocli] Listening on 127.0.0.1:{Port}");
    }

    private static void ListenLoop()
    {
        try
        {
            Listener = new TcpListener(IPAddress.Loopback, Port);
            Listener.Start();

            while (Running)
            {
                TcpClient client = Listener.AcceptTcpClient();
                Thread t = new Thread(() => HandleClient(client));
                t.IsBackground = true;
                t.Start();
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine("[muocli] Listener stopped: " + ex.Message);
        }
    }

    private static void HandleClient(TcpClient client)
    {
        try
        {
            using (client)
            using (NetworkStream stream = client.GetStream())
            using (StreamReader reader = new StreamReader(stream))
            using (StreamWriter writer = new StreamWriter(stream) { AutoFlush = true })
            {
                string? line = reader.ReadLine();

                if (line == null)
                    return;

                string[] parts = line.Split(' ', 2);

                if (parts.Length != 2 || parts[0] != Token)
                {
                    writer.WriteLine("ERR auth");
                    return;
                }

                CommandDispatcher.Dispatch(writer, parts[1].Trim());
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine("[muocli] Client handler failed: " + ex.Message);
        }
    }
}
