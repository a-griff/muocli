using System;
using System.Threading;
using Server;

internal static class ServerThread
{
    private const int ServerThreadTimeoutMs = 10000;

    public static string Run(Func<string> action)
    {
        string result = "ERR server-thread-failed";
        Exception? error = null;
        AutoResetEvent done = new AutoResetEvent(false);

        Core.LoopContext.Post(() =>
        {
            try
            {
                result = action();
            }
            catch (Exception ex)
            {
                error = ex;
            }
            finally
            {
                done.Set();
            }
        });

        if (!done.WaitOne(ServerThreadTimeoutMs))
            return "ERR server-thread-timeout";

        if (error != null)
            return "ERR exception: " + error.GetType().Name + ": " + error.Message;

        return result;
    }
}
