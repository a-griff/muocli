using System;

internal static class CommandText
{
    public static string Token(string cmd, int index)
    {
        string[] args = cmd.Split(' ', StringSplitOptions.RemoveEmptyEntries);

        if (index < 0 || index >= args.Length)
            return "";

        return args[index];
    }

    public static string Remainder(string cmd, int startIndex)
    {
        int pos = 0;
        int tokenIndex = 0;

        while (pos < cmd.Length)
        {
            while (pos < cmd.Length && cmd[pos] == ' ')
                pos++;

            if (pos >= cmd.Length)
                break;

            if (tokenIndex == startIndex)
                return cmd.Substring(pos).Trim();

            while (pos < cmd.Length && cmd[pos] != ' ')
                pos++;

            tokenIndex++;
        }

        return "";
    }
}
