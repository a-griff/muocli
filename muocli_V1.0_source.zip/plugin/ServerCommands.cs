using System.IO;
using Server;
using Server.Saves;

internal static class ServerCommands
{
    public static void Dispatch(StreamWriter writer, string[] args)
    {
        switch (args[1])
        {
            case "save":
                Save(writer);
                return;

            case "restart":
                Restart(writer);
                return;

            case "shutdown":
                Shutdown(writer);
                return;
        }

        writer.WriteLine("ERR unknown-command");
    }

    private static void Save(StreamWriter writer)
    {
        string result = ServerThread.Run(() =>
        {
            AutoSave.Save();
            return "OK server-save-started";
        });

        writer.WriteLine(result);
    }

    private static void Restart(StreamWriter writer)
    {
        string result = ServerThread.Run(() =>
        {
            Core.Kill(true);
            return "OK server-restart";
        });

        writer.WriteLine(result);
    }

    private static void Shutdown(StreamWriter writer)
    {
        string result = ServerThread.Run(() =>
        {
            Core.Kill();
            return "OK server-shutdown";
        });

        writer.WriteLine(result);
    }
}
